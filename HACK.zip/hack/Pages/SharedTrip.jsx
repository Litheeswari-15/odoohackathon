import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { format, differenceInDays, eachDayOfInterval, parseISO, isWithinInterval } from 'date-fns';
import { 
  Calendar, MapPin, DollarSign, Clock, Globe, 
  Copy, ArrowRight, Share2, PlaneTakeoff
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Skeleton } from "@/components/ui/skeleton";
import { toast } from "sonner";
import { motion } from 'framer-motion';
import ActivityCard from '../components/trips/ActivityCard';

export default function SharedTrip() {
  const urlParams = new URLSearchParams(window.location.search);
  const shareCode = urlParams.get('code');

  const { data: trips = [], isLoading: tripLoading } = useQuery({
    queryKey: ['sharedTrip', shareCode],
    queryFn: async () => {
      // Try share_code first, then id
      let result = await base44.entities.Trip.filter({ share_code: shareCode });
      if (result.length === 0) {
        result = await base44.entities.Trip.filter({ id: shareCode });
      }
      return result;
    },
    enabled: !!shareCode,
  });

  const trip = trips[0];

  const { data: stops = [] } = useQuery({
    queryKey: ['sharedStops', trip?.id],
    queryFn: () => base44.entities.TripStop.filter({ trip_id: trip.id }, 'order'),
    enabled: !!trip?.id,
  });

  const { data: activities = [] } = useQuery({
    queryKey: ['sharedActivities', trip?.id],
    queryFn: () => base44.entities.Activity.filter({ trip_id: trip.id }, 'date'),
    enabled: !!trip?.id,
  });

  const handleCopyLink = () => {
    navigator.clipboard.writeText(window.location.href);
    toast.success('Link copied to clipboard!');
  };

  if (tripLoading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-emerald-50/30 p-6 lg:p-8">
        <div className="max-w-4xl mx-auto">
          <Skeleton className="h-72 rounded-2xl mb-6" />
          <Skeleton className="h-96 rounded-2xl" />
        </div>
      </div>
    );
  }

  if (!trip) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-emerald-50/30 flex items-center justify-center p-6">
        <div className="text-center">
          <div className="w-20 h-20 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-6">
            <Globe className="h-10 w-10 text-slate-400" />
          </div>
          <h1 className="text-2xl font-bold text-slate-900 mb-2">Trip Not Found</h1>
          <p className="text-slate-500 mb-6">This trip doesn't exist or is no longer shared.</p>
          <Link to={createPageUrl('Dashboard')}>
            <Button className="bg-emerald-600 hover:bg-emerald-700">
              Go to GlobeTrotter
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  const days = differenceInDays(new Date(trip.end_date), new Date(trip.start_date)) + 1;
  const totalBudget = stops.reduce((sum, s) => sum + (s.accommodation_cost || 0) + (s.transport_cost || 0), 0) 
    + activities.reduce((sum, a) => sum + (a.cost || 0), 0);

  const tripDays = trip.start_date && trip.end_date 
    ? eachDayOfInterval({ start: parseISO(trip.start_date), end: parseISO(trip.end_date) })
    : [];

  const getDayActivities = (date) => {
    const dateStr = format(date, 'yyyy-MM-dd');
    return activities.filter(a => a.date === dateStr);
  };

  const getDayStop = (date) => {
    return stops.find(stop => 
      isWithinInterval(date, {
        start: parseISO(stop.arrival_date),
        end: parseISO(stop.departure_date)
      })
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 via-white to-emerald-50/30">
      {/* Header */}
      <div className="bg-white border-b border-slate-200">
        <div className="max-w-4xl mx-auto px-6 py-4 flex items-center justify-between">
          <Link to={createPageUrl('Dashboard')} className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center">
              <Globe className="h-4 w-4 text-white" />
            </div>
            <span className="font-bold text-slate-800">GlobeTrotter</span>
          </Link>
          <Button variant="outline" size="sm" onClick={handleCopyLink}>
            <Share2 className="h-4 w-4 mr-2" />
            Share
          </Button>
        </div>
      </div>

      <div className="max-w-4xl mx-auto p-6 lg:p-8">
        {/* Trip Hero */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
        >
          <Card className="overflow-hidden border-0 shadow-xl rounded-2xl mb-8">
            <div className="relative h-64 lg:h-80">
              <img 
                src={trip.cover_image || "https://images.unsplash.com/photo-1488085061387-422e29b40080?w=1200&q=80"}
                alt={trip.name}
                className="w-full h-full object-cover"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />
              <div className="absolute bottom-0 left-0 right-0 p-6 lg:p-8">
                <Badge className="mb-3 bg-emerald-500/80 text-white border-0">
                  Shared Itinerary
                </Badge>
                <h1 className="text-3xl lg:text-4xl font-bold text-white mb-3">{trip.name}</h1>
                {trip.description && (
                  <p className="text-white/80 mb-4 max-w-2xl">{trip.description}</p>
                )}
                <div className="flex flex-wrap items-center gap-4 text-white/80 text-sm">
                  <div className="flex items-center gap-1.5">
                    <Calendar className="h-4 w-4" />
                    {format(new Date(trip.start_date), 'MMM d')} - {format(new Date(trip.end_date), 'MMM d, yyyy')}
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Clock className="h-4 w-4" />
                    {days} days
                  </div>
                  <div className="flex items-center gap-1.5">
                    <MapPin className="h-4 w-4" />
                    {stops.length} cities
                  </div>
                  {totalBudget > 0 && (
                    <div className="flex items-center gap-1.5">
                      <DollarSign className="h-4 w-4" />
                      ${totalBudget.toLocaleString()}
                    </div>
                  )}
                </div>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Route Overview */}
        {stops.length > 0 && (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="mb-8"
          >
            <h2 className="text-xl font-bold text-slate-900 mb-4">Route</h2>
            <Card className="border-0 shadow-md rounded-xl">
              <CardContent className="p-4">
                <div className="flex items-center flex-wrap gap-3">
                  {stops.map((stop, i) => (
                    <React.Fragment key={stop.id}>
                      <div className="flex items-center gap-2 px-4 py-2 bg-slate-50 rounded-full">
                        <div className="w-6 h-6 rounded-full bg-emerald-500 text-white flex items-center justify-center text-xs font-bold">
                          {i + 1}
                        </div>
                        <span className="font-medium">{stop.city_name}</span>
                        <span className="text-slate-400 text-sm">{stop.country}</span>
                      </div>
                      {i < stops.length - 1 && (
                        <ArrowRight className="h-4 w-4 text-slate-300" />
                      )}
                    </React.Fragment>
                  ))}
                </div>
              </CardContent>
            </Card>
          </motion.div>
        )}

        {/* Day by Day Itinerary */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
        >
          <h2 className="text-xl font-bold text-slate-900 mb-4">Day-by-Day Itinerary</h2>
          <div className="space-y-4">
            {tripDays.map((day, i) => {
              const dayActivities = getDayActivities(day);
              const stop = getDayStop(day);

              return (
                <Card key={i} className="border-0 shadow-md rounded-xl overflow-hidden">
                  <CardHeader className="bg-slate-50 py-4">
                    <div className="flex items-center gap-4">
                      <div className="w-14 text-center">
                        <p className="text-xs text-slate-500 uppercase">{format(day, 'EEE')}</p>
                        <p className="text-2xl font-bold text-slate-900">{format(day, 'd')}</p>
                        <p className="text-xs text-slate-500">{format(day, 'MMM')}</p>
                      </div>
                      <div className="flex-1">
                        <p className="text-sm text-slate-500">Day {i + 1}</p>
                        {stop ? (
                          <p className="font-semibold text-slate-900 flex items-center gap-2">
                            <MapPin className="h-4 w-4 text-emerald-500" />
                            {stop.city_name}, {stop.country}
                          </p>
                        ) : (
                          <p className="text-slate-400">No location</p>
                        )}
                      </div>
                    </div>
                  </CardHeader>
                  <CardContent className="p-4">
                    {dayActivities.length > 0 ? (
                      <div className="space-y-3">
                        {dayActivities.map(activity => (
                          <ActivityCard
                            key={activity.id}
                            activity={activity}
                            compact
                          />
                        ))}
                      </div>
                    ) : (
                      <p className="text-slate-400 text-sm py-2">No activities planned</p>
                    )}
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </motion.div>

        {/* Copy Trip CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
          className="mt-8"
        >
          <Card className="bg-gradient-to-r from-emerald-500 to-teal-600 border-0 text-white overflow-hidden">
            <CardContent className="p-6 lg:p-8">
              <div className="flex flex-col lg:flex-row items-center gap-6">
                <div className="flex-1 text-center lg:text-left">
                  <h3 className="text-2xl font-bold mb-2">Love this itinerary?</h3>
                  <p className="text-white/80">
                    Create your own trip on GlobeTrotter and start planning your adventure!
                  </p>
                </div>
                <Link to={createPageUrl('CreateTrip')}>
                  <Button size="lg" className="bg-white text-emerald-600 hover:bg-white/90">
                    <PlaneTakeoff className="mr-2 h-5 w-5" />
                    Start Planning
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
}