import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { 
  Search, MapPin, DollarSign, Star, Filter, Globe, 
  Heart, ArrowRight, Loader2, TrendingUp
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Skeleton } from "@/components/ui/skeleton";
import { motion } from 'framer-motion';
import { cn } from "@/lib/utils";

// Sample city data (in real app, would come from database)
const sampleCities = [
  { id: '1', name: 'Paris', country: 'France', region: 'Europe', image_url: 'https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=600&q=80', cost_index: 4, popularity_score: 95, avg_daily_cost: 200, description: 'The City of Light captivates with iconic landmarks, world-class museums, and romantic streets.' },
  { id: '2', name: 'Tokyo', country: 'Japan', region: 'Asia', image_url: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=600&q=80', cost_index: 4, popularity_score: 92, avg_daily_cost: 180, description: 'A mesmerizing blend of ultra-modern and traditional, from neon-lit streets to ancient temples.' },
  { id: '3', name: 'Bali', country: 'Indonesia', region: 'Asia', image_url: 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=600&q=80', cost_index: 2, popularity_score: 88, avg_daily_cost: 80, description: 'Tropical paradise with stunning beaches, lush rice terraces, and vibrant spiritual culture.' },
  { id: '4', name: 'Barcelona', country: 'Spain', region: 'Europe', image_url: 'https://images.unsplash.com/photo-1583422409516-2895a77efded?w=600&q=80', cost_index: 3, popularity_score: 90, avg_daily_cost: 150, description: 'Architectural wonders, beautiful beaches, and a vibrant nightlife scene.' },
  { id: '5', name: 'New York', country: 'USA', region: 'North America', image_url: 'https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?w=600&q=80', cost_index: 5, popularity_score: 94, avg_daily_cost: 300, description: 'The city that never sleeps offers endless entertainment, culture, and iconic landmarks.' },
  { id: '6', name: 'Dubai', country: 'UAE', region: 'Middle East', image_url: 'https://images.unsplash.com/photo-1512453979798-5ea266f8880c?w=600&q=80', cost_index: 4, popularity_score: 85, avg_daily_cost: 250, description: 'Futuristic skyline, luxury shopping, and desert adventures in this modern oasis.' },
  { id: '7', name: 'Sydney', country: 'Australia', region: 'Oceania', image_url: 'https://images.unsplash.com/photo-1506973035872-a4ec16b8e8d9?w=600&q=80', cost_index: 4, popularity_score: 87, avg_daily_cost: 200, description: 'Stunning harbor, world-famous beaches, and a laid-back lifestyle.' },
  { id: '8', name: 'Rome', country: 'Italy', region: 'Europe', image_url: 'https://images.unsplash.com/photo-1552832230-c0197dd311b5?w=600&q=80', cost_index: 3, popularity_score: 91, avg_daily_cost: 160, description: 'Ancient history meets modern Italian charm in the Eternal City.' },
  { id: '9', name: 'Bangkok', country: 'Thailand', region: 'Asia', image_url: 'https://images.unsplash.com/photo-1508009603885-50cf7c579365?w=600&q=80', cost_index: 1, popularity_score: 86, avg_daily_cost: 50, description: 'Vibrant street life, ornate temples, and incredible street food.' },
  { id: '10', name: 'Cape Town', country: 'South Africa', region: 'Africa', image_url: 'https://images.unsplash.com/photo-1580060839134-75a5edca2e99?w=600&q=80', cost_index: 2, popularity_score: 82, avg_daily_cost: 90, description: 'Stunning natural beauty with Table Mountain, beaches, and wine country.' },
  { id: '11', name: 'Marrakech', country: 'Morocco', region: 'Africa', image_url: 'https://images.unsplash.com/photo-1597212618440-806262de4f6b?w=600&q=80', cost_index: 2, popularity_score: 80, avg_daily_cost: 70, description: 'Exotic souks, stunning riads, and vibrant Moroccan culture.' },
  { id: '12', name: 'Reykjavik', country: 'Iceland', region: 'Europe', image_url: 'https://images.unsplash.com/photo-1504893524553-b855bce32c67?w=600&q=80', cost_index: 5, popularity_score: 78, avg_daily_cost: 280, description: 'Gateway to dramatic landscapes, Northern Lights, and geothermal wonders.' },
];

const sampleActivities = [
  { id: '1', city_name: 'Paris', name: 'Eiffel Tower Visit', category: 'sightseeing', estimated_cost: 25, rating: 4.8, image_url: 'https://images.unsplash.com/photo-1543349689-9a4d426bee8e?w=400&q=80' },
  { id: '2', city_name: 'Paris', name: 'Louvre Museum', category: 'culture', estimated_cost: 17, rating: 4.9, image_url: 'https://images.unsplash.com/photo-1499426600726-ac36215747eb?w=400&q=80' },
  { id: '3', city_name: 'Tokyo', name: 'Shibuya Crossing', category: 'sightseeing', estimated_cost: 0, rating: 4.5, image_url: 'https://images.unsplash.com/photo-1542051841857-5f90071e7989?w=400&q=80' },
  { id: '4', city_name: 'Tokyo', name: 'Tsukiji Market Tour', category: 'food', estimated_cost: 50, rating: 4.7, image_url: 'https://images.unsplash.com/photo-1553621042-f6e147245754?w=400&q=80' },
  { id: '5', city_name: 'Bali', name: 'Tegallalang Rice Terraces', category: 'nature', estimated_cost: 10, rating: 4.6, image_url: 'https://images.unsplash.com/photo-1531592937781-344ad608fabf?w=400&q=80' },
  { id: '6', city_name: 'Barcelona', name: 'La Sagrada Familia', category: 'culture', estimated_cost: 26, rating: 4.9, image_url: 'https://images.unsplash.com/photo-1566178849563-e17ceb98f911?w=400&q=80' },
];

const regions = ['All', 'Europe', 'Asia', 'North America', 'South America', 'Africa', 'Oceania', 'Middle East'];

export default function Explore() {
  const urlParams = new URLSearchParams(window.location.search);
  const cityParam = urlParams.get('city');

  const [search, setSearch] = useState(cityParam || '');
  const [region, setRegion] = useState('All');
  const [costFilter, setCostFilter] = useState('all');
  const [activeTab, setActiveTab] = useState('cities');
  const [favorites, setFavorites] = useState([]);

  // In a real app, fetch from database
  const cities = sampleCities;
  const activities = sampleActivities;

  const filteredCities = cities.filter(city => {
    const matchesSearch = city.name.toLowerCase().includes(search.toLowerCase()) ||
      city.country.toLowerCase().includes(search.toLowerCase());
    const matchesRegion = region === 'All' || city.region === region;
    const matchesCost = costFilter === 'all' || 
      (costFilter === 'budget' && city.cost_index <= 2) ||
      (costFilter === 'mid' && city.cost_index === 3) ||
      (costFilter === 'luxury' && city.cost_index >= 4);
    return matchesSearch && matchesRegion && matchesCost;
  });

  const filteredActivities = activities.filter(activity => {
    const matchesSearch = activity.name.toLowerCase().includes(search.toLowerCase()) ||
      activity.city_name.toLowerCase().includes(search.toLowerCase());
    return matchesSearch;
  });

  const toggleFavorite = (cityId) => {
    setFavorites(prev => 
      prev.includes(cityId) 
        ? prev.filter(id => id !== cityId)
        : [...prev, cityId]
    );
  };

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto">
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="text-center mb-10"
      >
        <h1 className="text-4xl lg:text-5xl font-bold text-slate-900 mb-4">
          Explore the World
        </h1>
        <p className="text-lg text-slate-500 max-w-2xl mx-auto">
          Discover amazing destinations and activities for your next adventure
        </p>
      </motion.div>

      {/* Search & Filters */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="bg-white rounded-2xl shadow-lg p-6 mb-8"
      >
        <div className="flex flex-col lg:flex-row gap-4">
          <div className="relative flex-1">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 h-5 w-5 text-slate-400" />
            <Input
              placeholder="Search destinations or activities..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="pl-12 h-12 text-lg border-slate-200"
            />
          </div>
          <Select value={region} onValueChange={setRegion}>
            <SelectTrigger className="w-full lg:w-48 h-12">
              <Globe className="h-4 w-4 mr-2 text-slate-400" />
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {regions.map(r => (
                <SelectItem key={r} value={r}>{r}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Select value={costFilter} onValueChange={setCostFilter}>
            <SelectTrigger className="w-full lg:w-48 h-12">
              <DollarSign className="h-4 w-4 mr-2 text-slate-400" />
              <SelectValue placeholder="Budget" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Budgets</SelectItem>
              <SelectItem value="budget">Budget Friendly</SelectItem>
              <SelectItem value="mid">Mid-Range</SelectItem>
              <SelectItem value="luxury">Luxury</SelectItem>
            </SelectContent>
          </Select>
        </div>

        <Tabs value={activeTab} onValueChange={setActiveTab} className="mt-6">
          <TabsList className="bg-slate-100">
            <TabsTrigger value="cities" className="data-[state=active]:bg-white">
              <MapPin className="h-4 w-4 mr-2" />
              Cities
            </TabsTrigger>
            <TabsTrigger value="activities" className="data-[state=active]:bg-white">
              <Star className="h-4 w-4 mr-2" />
              Activities
            </TabsTrigger>
          </TabsList>
        </Tabs>
      </motion.div>

      {/* Cities Grid */}
      {activeTab === 'cities' && (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredCities.map((city, i) => (
            <motion.div
              key={city.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <Card className="group overflow-hidden bg-white border-0 shadow-md hover:shadow-xl transition-all duration-300 rounded-2xl h-full">
                <div className="relative h-56 overflow-hidden">
                  <img 
                    src={city.image_url}
                    alt={city.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-transparent to-transparent" />
                  
                  <button
                    onClick={() => toggleFavorite(city.id)}
                    className="absolute top-4 right-4 p-2 rounded-full bg-white/20 backdrop-blur-sm hover:bg-white/40 transition-colors"
                  >
                    <Heart className={cn(
                      "h-5 w-5 transition-colors",
                      favorites.includes(city.id) ? "fill-red-500 text-red-500" : "text-white"
                    )} />
                  </button>

                  <div className="absolute bottom-4 left-4 right-4">
                    <h3 className="text-2xl font-bold text-white">{city.name}</h3>
                    <p className="text-white/80 flex items-center gap-1">
                      <MapPin className="h-4 w-4" />
                      {city.country}
                    </p>
                  </div>
                </div>

                <CardContent className="p-5">
                  <p className="text-sm text-slate-600 mb-4 line-clamp-2">{city.description}</p>
                  
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center gap-1">
                      {[...Array(5)].map((_, j) => (
                        <DollarSign 
                          key={j} 
                          className={cn(
                            "h-4 w-4",
                            j < city.cost_index ? "text-emerald-500" : "text-slate-200"
                          )}
                        />
                      ))}
                    </div>
                    <div className="flex items-center gap-1 text-sm text-slate-500">
                      <TrendingUp className="h-4 w-4 text-amber-500" />
                      {city.popularity_score}% popular
                    </div>
                  </div>

                  <div className="flex items-center justify-between pt-4 border-t border-slate-100">
                    <div>
                      <p className="text-xs text-slate-500">From</p>
                      <p className="font-semibold text-slate-900">${city.avg_daily_cost}/day</p>
                    </div>
                    <Link to={createPageUrl(`CreateTrip?city=${city.name}`)}>
                      <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">
                        Plan Trip
                        <ArrowRight className="ml-2 h-4 w-4" />
                      </Button>
                    </Link>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      {/* Activities Grid */}
      {activeTab === 'activities' && (
        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {filteredActivities.map((activity, i) => (
            <motion.div
              key={activity.id}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: i * 0.05 }}
            >
              <Card className="group overflow-hidden bg-white border-0 shadow-md hover:shadow-xl transition-all duration-300 rounded-2xl">
                <div className="relative h-48 overflow-hidden">
                  <img 
                    src={activity.image_url}
                    alt={activity.name}
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <Badge className="absolute top-4 left-4 bg-white/90 text-slate-700">
                    {activity.category}
                  </Badge>
                </div>
                <CardContent className="p-5">
                  <h3 className="font-semibold text-lg text-slate-900">{activity.name}</h3>
                  <p className="text-sm text-slate-500 flex items-center gap-1 mt-1">
                    <MapPin className="h-3.5 w-3.5" />
                    {activity.city_name}
                  </p>
                  <div className="flex items-center justify-between mt-4 pt-4 border-t border-slate-100">
                    <div className="flex items-center gap-1">
                      <Star className="h-4 w-4 fill-amber-400 text-amber-400" />
                      <span className="font-medium">{activity.rating}</span>
                    </div>
                    <p className="font-semibold text-emerald-600">
                      {activity.estimated_cost > 0 ? `$${activity.estimated_cost}` : 'Free'}
                    </p>
                  </div>
                </CardContent>
              </Card>
            </motion.div>
          ))}
        </div>
      )}

      {/* Empty State */}
      {((activeTab === 'cities' && filteredCities.length === 0) || 
        (activeTab === 'activities' && filteredActivities.length === 0)) && (
        <div className="text-center py-16">
          <Globe className="h-16 w-16 mx-auto text-slate-300 mb-4" />
          <h3 className="text-xl font-semibold text-slate-900 mb-2">No results found</h3>
          <p className="text-slate-500">Try adjusting your search or filters</p>
        </div>
      )}
    </div>
  );
}