import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { base44 } from '@/api/base44Client';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { format, differenceInDays, eachDayOfInterval, parseISO, isWithinInterval } from 'date-fns';
import { 
  ArrowLeft, Calendar, MapPin, DollarSign, Plus, Share2, 
  Settings, Clock, MoreVertical, Edit, Trash2, PlaneTakeoff,
  ChevronDown, ChevronRight, Eye
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Skeleton } from "@/components/ui/skeleton";
import {
  Collapsible,
  CollapsibleContent,
  CollapsibleTrigger,
} from "@/components/ui/collapsible";
import { toast } from "sonner";
import { motion } from 'framer-motion';
import StopCard from '../components/trips/StopCard';
import ActivityCard from '../components/trips/ActivityCard';
import AddStopDialog from '../components/dialogs/AddStopDialog';
import AddActivityDialog from '../components/dialogs/AddActivityDialog';
import BudgetBreakdown from '../components/trips/BudgetBreakdown';

export default function TripDetail() {
  const navigate = useNavigate();
  const urlParams = new URLSearchParams(window.location.search);
  const tripId = urlParams.get('id');
  const queryClient = useQueryClient();

  const [activeTab, setActiveTab] = useState('itinerary');
  const [showAddStop, setShowAddStop] = useState(false);
  const [showAddActivity, setShowAddActivity] = useState(false);
  const [selectedStop, setSelectedStop] = useState(null);
  const [expandedDays, setExpandedDays] = useState({});

  const { data: trip, isLoading: tripLoading } = useQuery({
    queryKey: ['trip', tripId],
    queryFn: () => base44.entities.Trip.filter({ id: tripId }).then(t => t[0]),
    enabled: !!tripId,
  });

  const { data: stops = [], isLoading: stopsLoading } = useQuery({
    queryKey: ['stops', tripId],
    queryFn: () => base44.entities.TripStop.filter({ trip_id: tripId }, 'order'),
    enabled: !!tripId,
  });

  const { data: activities = [] } = useQuery({
    queryKey: ['activities', tripId],
    queryFn: () => base44.entities.Activity.filter({ trip_id: tripId }, 'order'),
    enabled: !!tripId,
  });

  const deleteStopMutation = useMutation({
    mutationFn: (stopId) => base44.entities.TripStop.delete(stopId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['stops', tripId] });
      toast.success('Stop removed');
    },
  });

  const deleteActivityMutation = useMutation({
    mutationFn: (activityId) => base44.entities.Activity.delete(activityId),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['activities', tripId] });
      toast.success('Activity removed');
    },
  });

  const toggleActivityBooked = useMutation({
    mutationFn: (activity) => base44.entities.Activity.update(activity.id, { 
      is_booked: !activity.is_booked 
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['activities', tripId] });
    },
  });

  if (!tripId) {
    navigate(createPageUrl('MyTrips'));
    return null;
  }

  if (tripLoading) {
    return (
      <div className="p-6 lg:p-8 max-w-6xl mx-auto">
        <Skeleton className="h-64 rounded-2xl mb-6" />
        <Skeleton className="h-96 rounded-2xl" />
      </div>
    );
  }

  if (!trip) {
    return (
      <div className="p-6 lg:p-8 max-w-6xl mx-auto text-center py-20">
        <h2 className="text-2xl font-bold text-slate-900 mb-4">Trip not found</h2>
        <Link to={createPageUrl('MyTrips')}>
          <Button>Go to My Trips</Button>
        </Link>
      </div>
    );
  }

  const days = differenceInDays(new Date(trip.end_date), new Date(trip.start_date)) + 1;
  const totalBudget = stops.reduce((sum, s) => sum + (s.accommodation_cost || 0) + (s.transport_cost || 0), 0) 
    + activities.reduce((sum, a) => sum + (a.cost || 0), 0);

  const handleShare = () => {
    const url = `${window.location.origin}${createPageUrl(`SharedTrip?code=${trip.share_code || trip.id}`)}`;
    navigator.clipboard.writeText(url);
    toast.success('Share link copied!');
  };

  const toggleDay = (day) => {
    setExpandedDays(prev => ({ ...prev, [day]: !prev[day] }));
  };

  // Generate calendar view data
  const tripDays = trip.start_date && trip.end_date 
    ? eachDayOfInterval({ start: parseISO(trip.start_date), end: parseISO(trip.end_date) })
    : [];

  const getDayActivities = (date) => {
    const dateStr = format(date, 'yyyy-MM-dd');
    return activities.filter(a => a.date === dateStr);
  };

  const getDayStop = (date) => {
    return stops.find(stop => 
      isWithinInterval(date, {
        start: parseISO(stop.arrival_date),
        end: parseISO(stop.departure_date)
      })
    );
  };

  return (
    <div className="p-6 lg:p-8 max-w-6xl mx-auto">
      {/* Header */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Button 
          variant="ghost" 
          onClick={() => navigate(createPageUrl('MyTrips'))}
          className="mb-4 -ml-2 text-slate-600 hover:text-slate-900"
        >
          <ArrowLeft className="mr-2 h-4 w-4" />
          My Trips
        </Button>

        {/* Trip Hero */}
        <Card className="overflow-hidden border-0 shadow-xl rounded-2xl mb-6">
          <div className="relative h-48 lg:h-64">
            <img 
              src={trip.cover_image || "https://images.unsplash.com/photo-1488085061387-422e29b40080?w=1200&q=80"}
              alt={trip.name}
              className="w-full h-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/30 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-6 lg:p-8">
              <Badge className="mb-3 bg-white/20 text-white border-0">
                {trip.status?.replace('_', ' ')}
              </Badge>
              <h1 className="text-3xl lg:text-4xl font-bold text-white mb-2">{trip.name}</h1>
              <div className="flex flex-wrap items-center gap-4 text-white/80 text-sm">
                <div className="flex items-center gap-1.5">
                  <Calendar className="h-4 w-4" />
                  {format(new Date(trip.start_date), 'MMM d')} - {format(new Date(trip.end_date), 'MMM d, yyyy')}
                </div>
                <div className="flex items-center gap-1.5">
                  <Clock className="h-4 w-4" />
                  {days} days
                </div>
                <div className="flex items-center gap-1.5">
                  <MapPin className="h-4 w-4" />
                  {stops.length} cities
                </div>
                <div className="flex items-center gap-1.5">
                  <DollarSign className="h-4 w-4" />
                  ${totalBudget.toLocaleString()}
                </div>
              </div>
            </div>
            <div className="absolute top-4 right-4 flex gap-2">
              <Button 
                size="sm" 
                variant="secondary"
                onClick={handleShare}
                className="bg-white/20 hover:bg-white/30 text-white border-0 backdrop-blur-sm"
              >
                <Share2 className="h-4 w-4 mr-1.5" />
                Share
              </Button>
              <Link to={createPageUrl(`EditTrip?id=${trip.id}`)}>
                <Button 
                  size="sm" 
                  variant="secondary"
                  className="bg-white/20 hover:bg-white/30 text-white border-0 backdrop-blur-sm"
                >
                  <Settings className="h-4 w-4" />
                </Button>
              </Link>
            </div>
          </div>
        </Card>
      </motion.div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-white border border-slate-200 p-1 mb-6">
          <TabsTrigger value="itinerary" className="data-[state=active]:bg-slate-100">
            Itinerary
          </TabsTrigger>
          <TabsTrigger value="calendar" className="data-[state=active]:bg-slate-100">
            Calendar
          </TabsTrigger>
          <TabsTrigger value="budget" className="data-[state=active]:bg-slate-100">
            Budget
          </TabsTrigger>
        </TabsList>

        {/* Itinerary Tab */}
        <TabsContent value="itinerary" className="mt-0">
          <div className="grid lg:grid-cols-3 gap-6">
            {/* Stops Column */}
            <div className="lg:col-span-2 space-y-4">
              <div className="flex items-center justify-between">
                <h2 className="text-xl font-bold text-slate-900">Cities & Stops</h2>
                <Button onClick={() => setShowAddStop(true)} className="bg-emerald-600 hover:bg-emerald-700">
                  <Plus className="h-4 w-4 mr-1.5" />
                  Add Stop
                </Button>
              </div>

              {stopsLoading ? (
                <div className="space-y-4">
                  {[1, 2, 3].map(i => <Skeleton key={i} className="h-32 rounded-xl" />)}
                </div>
              ) : stops.length > 0 ? (
                <div className="space-y-4">
                  {stops.map((stop, i) => (
                    <div key={stop.id}>
                      <StopCard
                        stop={stop}
                        index={i}
                        activitiesCount={activities.filter(a => a.stop_id === stop.id).length}
                        onDelete={(s) => deleteStopMutation.mutate(s.id)}
                        onEdit={(s) => {
                          setSelectedStop(s);
                          setShowAddStop(true);
                        }}
                      />
                      {/* Activities for this stop */}
                      <div className="ml-14 mt-2 space-y-2">
                        {activities.filter(a => a.stop_id === stop.id).map(activity => (
                          <ActivityCard
                            key={activity.id}
                            activity={activity}
                            compact
                            onDelete={(a) => deleteActivityMutation.mutate(a.id)}
                            onToggleBooked={(a) => toggleActivityBooked.mutate(a)}
                          />
                        ))}
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => {
                            setSelectedStop(stop);
                            setShowAddActivity(true);
                          }}
                          className="text-emerald-600 hover:text-emerald-700 hover:bg-emerald-50 w-full justify-start"
                        >
                          <Plus className="h-4 w-4 mr-1.5" />
                          Add Activity
                        </Button>
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <Card className="border-dashed border-2 border-slate-200 bg-slate-50/50">
                  <CardContent className="py-12 text-center">
                    <MapPin className="h-12 w-12 mx-auto text-slate-300 mb-4" />
                    <h3 className="text-lg font-semibold text-slate-900 mb-2">No stops added yet</h3>
                    <p className="text-slate-500 mb-4">Start building your itinerary by adding cities</p>
                    <Button onClick={() => setShowAddStop(true)} className="bg-emerald-600 hover:bg-emerald-700">
                      <Plus className="h-4 w-4 mr-1.5" />
                      Add Your First Stop
                    </Button>
                  </CardContent>
                </Card>
              )}
            </div>

            {/* Quick Stats */}
            <div className="space-y-4">
              <Card className="bg-gradient-to-br from-emerald-500 to-teal-600 border-0 text-white">
                <CardContent className="p-5">
                  <h3 className="text-white/80 text-sm mb-1">Total Budget</h3>
                  <p className="text-3xl font-bold">${totalBudget.toLocaleString()}</p>
                  <p className="text-white/70 text-sm mt-1">
                    ~${Math.round(totalBudget / days)} per day
                  </p>
                </CardContent>
              </Card>

              <Card>
                <CardHeader className="pb-3">
                  <CardTitle className="text-base">Trip Summary</CardTitle>
                </CardHeader>
                <CardContent className="space-y-3 text-sm">
                  <div className="flex justify-between">
                    <span className="text-slate-500">Duration</span>
                    <span className="font-medium">{days} days</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Cities</span>
                    <span className="font-medium">{stops.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Activities</span>
                    <span className="font-medium">{activities.length}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Booked</span>
                    <span className="font-medium">{activities.filter(a => a.is_booked).length}</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        </TabsContent>

        {/* Calendar Tab */}
        <TabsContent value="calendar" className="mt-0">
          <Card>
            <CardContent className="p-6">
              <div className="space-y-2">
                {tripDays.map((day, i) => {
                  const dayActivities = getDayActivities(day);
                  const stop = getDayStop(day);
                  const isExpanded = expandedDays[format(day, 'yyyy-MM-dd')];

                  return (
                    <Collapsible key={i} open={isExpanded}>
                      <CollapsibleTrigger 
                        onClick={() => toggleDay(format(day, 'yyyy-MM-dd'))}
                        className="w-full"
                      >
                        <div className="flex items-center gap-4 p-4 rounded-xl hover:bg-slate-50 transition-colors">
                          <div className="w-16 text-center">
                            <p className="text-xs text-slate-500 uppercase">{format(day, 'EEE')}</p>
                            <p className="text-2xl font-bold text-slate-900">{format(day, 'd')}</p>
                            <p className="text-xs text-slate-500">{format(day, 'MMM')}</p>
                          </div>
                          <div className="flex-1 text-left">
                            {stop ? (
                              <div className="flex items-center gap-2">
                                <MapPin className="h-4 w-4 text-emerald-500" />
                                <span className="font-medium">{stop.city_name}</span>
                                <span className="text-slate-400">•</span>
                                <span className="text-slate-500 text-sm">{dayActivities.length} activities</span>
                              </div>
                            ) : (
                              <span className="text-slate-400">No stop planned</span>
                            )}
                          </div>
                          {isExpanded ? (
                            <ChevronDown className="h-5 w-5 text-slate-400" />
                          ) : (
                            <ChevronRight className="h-5 w-5 text-slate-400" />
                          )}
                        </div>
                      </CollapsibleTrigger>
                      <CollapsibleContent>
                        <div className="ml-20 pb-4 space-y-2">
                          {dayActivities.length > 0 ? (
                            dayActivities.map(activity => (
                              <ActivityCard
                                key={activity.id}
                                activity={activity}
                                compact
                              />
                            ))
                          ) : (
                            <p className="text-sm text-slate-400 py-2">No activities planned</p>
                          )}
                        </div>
                      </CollapsibleContent>
                    </Collapsible>
                  );
                })}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Budget Tab */}
        <TabsContent value="budget" className="mt-0">
          <BudgetBreakdown 
            stops={stops} 
            activities={activities} 
            days={days}
            currency={trip.currency || 'USD'}
          />
        </TabsContent>
      </Tabs>

      {/* Dialogs */}
      <AddStopDialog
        open={showAddStop}
        onClose={() => {
          setShowAddStop(false);
          setSelectedStop(null);
        }}
        tripId={tripId}
        tripDates={{ start: trip.start_date, end: trip.end_date }}
        editingStop={selectedStop}
      />

      <AddActivityDialog
        open={showAddActivity}
        onClose={() => {
          setShowAddActivity(false);
          setSelectedStop(null);
        }}
        tripId={tripId}
        stop={selectedStop}
      />
    </div>
  );
}