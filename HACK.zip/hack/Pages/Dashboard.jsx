import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../utils';
import { base44 } from '@/api/base44Client';
import { useQuery } from '@tanstack/react-query';
import { format, differenceInDays, isAfter, isBefore, isWithinInterval } from 'date-fns';
import { 
  PlaneTakeoff, MapPin, Calendar, TrendingUp, 
  DollarSign, Globe, ArrowRight, Sparkles, Plus
} from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import TripCard from '../components/trips/TripCard';
import { motion } from 'framer-motion';

const recommendedDestinations = [
  { name: "Tokyo", country: "Japan", image: "https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?w=400&q=80", costIndex: 3 },
  { name: "Paris", country: "France", image: "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?w=400&q=80", costIndex: 4 },
  { name: "Bali", country: "Indonesia", image: "https://images.unsplash.com/photo-1537996194471-e657df975ab4?w=400&q=80", costIndex: 2 },
  { name: "Barcelona", country: "Spain", image: "https://images.unsplash.com/photo-1583422409516-2895a77efded?w=400&q=80", costIndex: 3 },
];

export default function Dashboard() {
  const [user, setUser] = useState(null);

  useEffect(() => {
    base44.auth.me().then(setUser).catch(() => {});
  }, []);

  const { data: trips = [], isLoading: tripsLoading } = useQuery({
    queryKey: ['trips'],
    queryFn: () => base44.entities.Trip.list('-created_date'),
  });

  const { data: stops = [] } = useQuery({
    queryKey: ['stops'],
    queryFn: () => base44.entities.TripStop.list(),
  });

  const today = new Date();
  
  const upcomingTrips = trips.filter(trip => 
    isAfter(new Date(trip.start_date), today) || 
    isWithinInterval(today, { start: new Date(trip.start_date), end: new Date(trip.end_date) })
  ).slice(0, 3);

  const totalTrips = trips.length;
  const totalCities = new Set(stops.map(s => s.city_name)).size;
  const totalBudget = trips.reduce((sum, t) => sum + (t.total_budget || 0), 0);
  const ongoingTrip = trips.find(trip => 
    isWithinInterval(today, { start: new Date(trip.start_date), end: new Date(trip.end_date) })
  );

  const getStopsCount = (tripId) => stops.filter(s => s.trip_id === tripId).length;

  return (
    <div className="p-6 lg:p-8 max-w-7xl mx-auto">
      {/* Welcome Section */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="mb-8"
      >
        <h1 className="text-3xl lg:text-4xl font-bold text-slate-900">
          Welcome back{user?.full_name ? `, ${user.full_name.split(' ')[0]}` : ''} 👋
        </h1>
        <p className="text-slate-500 mt-2 text-lg">
          Ready to plan your next adventure?
        </p>
      </motion.div>

      {/* Stats Grid */}
      <motion.div 
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.1 }}
        className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8"
      >
        <Card className="bg-gradient-to-br from-emerald-500 to-teal-600 border-0 text-white overflow-hidden relative">
          <div className="absolute top-0 right-0 w-20 h-20 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2" />
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-white/20 rounded-xl">
                <PlaneTakeoff className="h-5 w-5" />
              </div>
              <div>
                <p className="text-white/80 text-sm">Total Trips</p>
                <p className="text-2xl font-bold">{totalTrips}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-rose-500 to-pink-600 border-0 text-white overflow-hidden relative">
          <div className="absolute top-0 right-0 w-20 h-20 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2" />
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-white/20 rounded-xl">
                <MapPin className="h-5 w-5" />
              </div>
              <div>
                <p className="text-white/80 text-sm">Cities Visited</p>
                <p className="text-2xl font-bold">{totalCities}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-violet-500 to-purple-600 border-0 text-white overflow-hidden relative">
          <div className="absolute top-0 right-0 w-20 h-20 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2" />
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-white/20 rounded-xl">
                <DollarSign className="h-5 w-5" />
              </div>
              <div>
                <p className="text-white/80 text-sm">Total Budget</p>
                <p className="text-2xl font-bold">${totalBudget.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-gradient-to-br from-amber-500 to-orange-600 border-0 text-white overflow-hidden relative">
          <div className="absolute top-0 right-0 w-20 h-20 bg-white/10 rounded-full -translate-y-1/2 translate-x-1/2" />
          <CardContent className="p-5">
            <div className="flex items-center gap-3">
              <div className="p-2.5 bg-white/20 rounded-xl">
                <Globe className="h-5 w-5" />
              </div>
              <div>
                <p className="text-white/80 text-sm">Countries</p>
                <p className="text-2xl font-bold">{new Set(stops.map(s => s.country)).size}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </motion.div>

      {/* Ongoing Trip Alert */}
      {ongoingTrip && (
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.15 }}
        >
          <Card className="mb-8 bg-gradient-to-r from-emerald-50 to-teal-50 border-emerald-200 overflow-hidden">
            <CardContent className="p-6">
              <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-full bg-emerald-500 flex items-center justify-center animate-pulse">
                    <Sparkles className="h-6 w-6 text-white" />
                  </div>
                  <div>
                    <p className="text-sm font-medium text-emerald-600">Currently Traveling</p>
                    <h3 className="text-xl font-bold text-slate-900">{ongoingTrip.name}</h3>
                    <p className="text-sm text-slate-500">
                      {format(new Date(ongoingTrip.start_date), 'MMM d')} - {format(new Date(ongoingTrip.end_date), 'MMM d, yyyy')}
                    </p>
                  </div>
                </div>
                <Link to={createPageUrl(`TripDetail?id=${ongoingTrip.id}`)}>
                  <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">
                    View Itinerary
                    <ArrowRight className="ml-2 h-4 w-4" />
                  </Button>
                </Link>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      )}

      {/* Main Content Grid */}
      <div className="grid lg:grid-cols-3 gap-8">
        {/* Upcoming Trips */}
        <motion.div 
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.2 }}
          className="lg:col-span-2"
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-slate-900">Your Trips</h2>
            <Link to={createPageUrl('MyTrips')}>
              <Button variant="ghost" className="text-emerald-600 hover:text-emerald-700">
                View All
                <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </Link>
          </div>

          {tripsLoading ? (
            <div className="grid md:grid-cols-2 gap-6">
              {[1, 2].map(i => (
                <Skeleton key={i} className="h-80 rounded-2xl" />
              ))}
            </div>
          ) : upcomingTrips.length > 0 ? (
            <div className="grid md:grid-cols-2 gap-6">
              {upcomingTrips.map(trip => (
                <TripCard 
                  key={trip.id} 
                  trip={trip} 
                  stopsCount={getStopsCount(trip.id)}
                />
              ))}
            </div>
          ) : (
            <Card className="border-dashed border-2 border-slate-200 bg-slate-50/50">
              <CardContent className="p-12 text-center">
                <div className="w-16 h-16 rounded-full bg-slate-100 flex items-center justify-center mx-auto mb-4">
                  <PlaneTakeoff className="h-8 w-8 text-slate-400" />
                </div>
                <h3 className="text-lg font-semibold text-slate-900 mb-2">No trips yet</h3>
                <p className="text-slate-500 mb-6">Start planning your first adventure!</p>
                <Link to={createPageUrl('CreateTrip')}>
                  <Button className="bg-emerald-600 hover:bg-emerald-700 text-white">
                    <Plus className="mr-2 h-4 w-4" />
                    Plan Your First Trip
                  </Button>
                </Link>
              </CardContent>
            </Card>
          )}
        </motion.div>

        {/* Recommended Destinations */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-slate-900">Explore</h2>
            <Link to={createPageUrl('Explore')}>
              <Button variant="ghost" className="text-emerald-600 hover:text-emerald-700">
                See More
                <ArrowRight className="ml-1 h-4 w-4" />
              </Button>
            </Link>
          </div>

          <div className="space-y-4">
            {recommendedDestinations.map((dest, i) => (
              <Link key={i} to={createPageUrl(`Explore?city=${dest.name}`)}>
                <Card className="group overflow-hidden bg-white border-0 shadow-sm hover:shadow-md transition-all duration-300 cursor-pointer">
                  <CardContent className="p-0">
                    <div className="flex items-center gap-4">
                      <div className="w-20 h-20 overflow-hidden">
                        <img 
                          src={dest.image} 
                          alt={dest.name}
                          className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-300"
                        />
                      </div>
                      <div className="flex-1 pr-4">
                        <h4 className="font-semibold text-slate-900">{dest.name}</h4>
                        <p className="text-sm text-slate-500">{dest.country}</p>
                        <div className="flex items-center gap-1 mt-1">
                          {[...Array(5)].map((_, j) => (
                            <DollarSign 
                              key={j} 
                              className={`h-3 w-3 ${j < dest.costIndex ? 'text-emerald-500' : 'text-slate-200'}`}
                            />
                          ))}
                        </div>
                      </div>
                      <ArrowRight className="h-5 w-5 text-slate-400 group-hover:text-emerald-500 transition-colors mr-4" />
                    </div>
                  </CardContent>
                </Card>
              </Link>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}