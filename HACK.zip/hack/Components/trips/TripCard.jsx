import React from 'react';
import { Link } from 'react-router-dom';
import { createPageUrl } from '../../utils';
import { format, differenceInDays } from 'date-fns';
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { 
  Calendar, MapPin, DollarSign, MoreVertical, 
  Edit, Trash2, Share2, Eye 
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

const statusColors = {
  planning: "bg-amber-100 text-amber-700 border-amber-200",
  upcoming: "bg-blue-100 text-blue-700 border-blue-200",
  ongoing: "bg-emerald-100 text-emerald-700 border-emerald-200",
  completed: "bg-slate-100 text-slate-600 border-slate-200",
};

export default function TripCard({ trip, stopsCount = 0, onDelete, onShare }) {
  const days = differenceInDays(new Date(trip.end_date), new Date(trip.start_date)) + 1;

  const defaultImage = "https://images.unsplash.com/photo-1488085061387-422e29b40080?w=800&q=80";

  return (
    <Card className="group overflow-hidden bg-white border-0 shadow-sm hover:shadow-xl transition-all duration-300 rounded-2xl">
      <div className="relative h-48 overflow-hidden">
        <img 
          src={trip.cover_image || defaultImage}
          alt={trip.name}
          className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-black/60 via-black/20 to-transparent" />
        
        {/* Status Badge */}
        <Badge className={cn("absolute top-4 left-4 border", statusColors[trip.status])}>
          {trip.status?.replace('_', ' ')}
        </Badge>

        {/* Actions Menu */}
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button 
              variant="ghost" 
              size="icon" 
              className="absolute top-4 right-4 h-8 w-8 bg-white/20 backdrop-blur-sm hover:bg-white/40 text-white"
            >
              <MoreVertical className="h-4 w-4" />
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end" className="w-44">
            <DropdownMenuItem asChild>
              <Link to={createPageUrl(`TripDetail?id=${trip.id}`)} className="flex items-center">
                <Eye className="mr-2 h-4 w-4" />
                View Details
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem asChild>
              <Link to={createPageUrl(`EditTrip?id=${trip.id}`)} className="flex items-center">
                <Edit className="mr-2 h-4 w-4" />
                Edit Trip
              </Link>
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onShare?.(trip)}>
              <Share2 className="mr-2 h-4 w-4" />
              Share
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => onDelete?.(trip)} className="text-red-600">
              <Trash2 className="mr-2 h-4 w-4" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>

        {/* Trip Name Overlay */}
        <div className="absolute bottom-4 left-4 right-4">
          <h3 className="text-xl font-bold text-white truncate">{trip.name}</h3>
        </div>
      </div>

      <CardContent className="p-5">
        <div className="space-y-3">
          {/* Date Range */}
          <div className="flex items-center gap-2 text-sm text-slate-600">
            <Calendar className="h-4 w-4 text-emerald-500" />
            <span>
              {format(new Date(trip.start_date), 'MMM d')} - {format(new Date(trip.end_date), 'MMM d, yyyy')}
            </span>
            <span className="text-slate-400">•</span>
            <span className="font-medium">{days} days</span>
          </div>

          {/* Stats Row */}
          <div className="flex items-center gap-4 text-sm">
            <div className="flex items-center gap-1.5 text-slate-600">
              <MapPin className="h-4 w-4 text-rose-500" />
              <span>{stopsCount} {stopsCount === 1 ? 'city' : 'cities'}</span>
            </div>
            {trip.total_budget > 0 && (
              <div className="flex items-center gap-1.5 text-slate-600">
                <DollarSign className="h-4 w-4 text-amber-500" />
                <span>${trip.total_budget?.toLocaleString()}</span>
              </div>
            )}
          </div>

          {/* Description */}
          {trip.description && (
            <p className="text-sm text-slate-500 line-clamp-2">{trip.description}</p>
          )}
        </div>

        {/* View Button */}
        <Link to={createPageUrl(`TripDetail?id=${trip.id}`)}>
          <Button className="w-full mt-4 bg-slate-900 hover:bg-slate-800 text-white rounded-xl">
            View Itinerary
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}