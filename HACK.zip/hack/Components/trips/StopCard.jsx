import React from 'react';
import { format, differenceInDays } from 'date-fns';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  MapPin, Calendar, MoreVertical, Edit, Trash2, 
  GripVertical, DollarSign, Bed, Train
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export default function StopCard({ 
  stop, 
  index, 
  activitiesCount = 0,
  onEdit, 
  onDelete,
  isDragging = false,
  dragHandleProps = {}
}) {
  const nights = differenceInDays(new Date(stop.departure_date), new Date(stop.arrival_date));
  const totalCost = (stop.accommodation_cost || 0) + (stop.transport_cost || 0);

  return (
    <Card className={`bg-white border-0 shadow-sm hover:shadow-md transition-all duration-200 rounded-xl ${isDragging ? 'shadow-lg ring-2 ring-emerald-500' : ''}`}>
      <CardContent className="p-4">
        <div className="flex items-start gap-4">
          {/* Drag Handle */}
          <div 
            {...dragHandleProps}
            className="mt-1 cursor-grab active:cursor-grabbing p-1 rounded hover:bg-slate-100"
          >
            <GripVertical className="h-5 w-5 text-slate-400" />
          </div>

          {/* Order Number */}
          <div className="flex-shrink-0 w-10 h-10 rounded-full bg-gradient-to-br from-emerald-500 to-teal-600 flex items-center justify-center text-white font-bold text-sm shadow-lg shadow-emerald-500/25">
            {index + 1}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-3">
              <div>
                <h4 className="font-semibold text-slate-900 text-lg">{stop.city_name}</h4>
                <p className="text-sm text-slate-500 flex items-center gap-1 mt-0.5">
                  <MapPin className="h-3.5 w-3.5" />
                  {stop.country}
                </p>
              </div>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => onEdit?.(stop)}>
                    <Edit className="mr-2 h-4 w-4" />
                    Edit Stop
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onDelete?.(stop)} className="text-red-600">
                    <Trash2 className="mr-2 h-4 w-4" />
                    Remove
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            {/* Dates */}
            <div className="flex items-center gap-2 mt-3 text-sm text-slate-600">
              <Calendar className="h-4 w-4 text-slate-400" />
              <span>
                {format(new Date(stop.arrival_date), 'MMM d')} - {format(new Date(stop.departure_date), 'MMM d')}
              </span>
              <Badge variant="secondary" className="ml-1 bg-slate-100 text-slate-600">
                {nights} {nights === 1 ? 'night' : 'nights'}
              </Badge>
            </div>

            {/* Stats */}
            <div className="flex flex-wrap items-center gap-3 mt-3">
              {activitiesCount > 0 && (
                <Badge variant="outline" className="bg-emerald-50 text-emerald-700 border-emerald-200">
                  {activitiesCount} activities
                </Badge>
              )}
              {stop.accommodation_cost > 0 && (
                <div className="flex items-center gap-1 text-xs text-slate-500">
                  <Bed className="h-3.5 w-3.5" />
                  ${stop.accommodation_cost}
                </div>
              )}
              {stop.transport_cost > 0 && (
                <div className="flex items-center gap-1 text-xs text-slate-500">
                  <Train className="h-3.5 w-3.5" />
                  ${stop.transport_cost}
                </div>
              )}
            </div>

            {/* Notes */}
            {stop.notes && (
              <p className="text-sm text-slate-500 mt-2 line-clamp-2">{stop.notes}</p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  );
}