import React from 'react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Bed, Train, Utensils, Camera, ShoppingBag, Sparkles, DollarSign, TrendingUp, AlertTriangle } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, Tooltip } from 'recharts';

const categoryIcons = {
  sightseeing: Camera,
  food: Utensils,
  adventure: Sparkles,
  culture: Sparkles,
  shopping: ShoppingBag,
  relaxation: Sparkles,
  nightlife: Sparkles,
  nature: Sparkles,
  other: Sparkles,
};

const COLORS = ['#10b981', '#3b82f6', '#f59e0b', '#ec4899', '#8b5cf6', '#06b6d4'];

export default function BudgetBreakdown({ stops, activities, days, currency = 'USD' }) {
  // Calculate costs
  const accommodationTotal = stops.reduce((sum, s) => sum + (s.accommodation_cost || 0), 0);
  const transportTotal = stops.reduce((sum, s) => sum + (s.transport_cost || 0), 0);
  
  // Group activities by category
  const activityCosts = activities.reduce((acc, a) => {
    const cat = a.category || 'other';
    acc[cat] = (acc[cat] || 0) + (a.cost || 0);
    return acc;
  }, {});

  const activitiesTotal = Object.values(activityCosts).reduce((sum, cost) => sum + cost, 0);
  const grandTotal = accommodationTotal + transportTotal + activitiesTotal;
  const dailyAverage = days > 0 ? grandTotal / days : 0;

  // Data for pie chart
  const pieData = [
    { name: 'Accommodation', value: accommodationTotal, color: '#10b981' },
    { name: 'Transport', value: transportTotal, color: '#3b82f6' },
    ...Object.entries(activityCosts).map(([category, value], i) => ({
      name: category.charAt(0).toUpperCase() + category.slice(1),
      value,
      color: COLORS[(i + 2) % COLORS.length]
    }))
  ].filter(d => d.value > 0);

  // Data for bar chart (by stop)
  const stopData = stops.map(stop => {
    const stopActivities = activities.filter(a => a.stop_id === stop.id);
    const activitiesCost = stopActivities.reduce((sum, a) => sum + (a.cost || 0), 0);
    return {
      name: stop.city_name,
      accommodation: stop.accommodation_cost || 0,
      transport: stop.transport_cost || 0,
      activities: activitiesCost,
      total: (stop.accommodation_cost || 0) + (stop.transport_cost || 0) + activitiesCost
    };
  });

  const costBreakdown = [
    { label: 'Accommodation', value: accommodationTotal, icon: Bed, color: 'bg-emerald-500' },
    { label: 'Transport', value: transportTotal, icon: Train, color: 'bg-blue-500' },
    { label: 'Activities', value: activitiesTotal, icon: Camera, color: 'bg-amber-500' },
  ];

  return (
    <div className="grid lg:grid-cols-3 gap-6">
      {/* Total Budget Card */}
      <Card className="lg:col-span-1 bg-gradient-to-br from-emerald-500 to-teal-600 border-0 text-white">
        <CardContent className="p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-white/20 rounded-lg">
              <DollarSign className="h-6 w-6" />
            </div>
            <div>
              <p className="text-white/80 text-sm">Total Budget</p>
              <p className="text-3xl font-bold">${grandTotal.toLocaleString()}</p>
            </div>
          </div>
          <div className="space-y-3 pt-4 border-t border-white/20">
            <div className="flex justify-between items-center">
              <span className="text-white/80">Daily Average</span>
              <span className="font-semibold">${dailyAverage.toFixed(0)}/day</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-white/80">Trip Length</span>
              <span className="font-semibold">{days} days</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Cost Breakdown */}
      <Card className="lg:col-span-2">
        <CardHeader>
          <CardTitle className="text-lg">Cost Breakdown</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {costBreakdown.map((item, i) => (
            <div key={i} className="space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className={`p-2 rounded-lg ${item.color}/10`}>
                    <item.icon className={`h-4 w-4 ${item.color.replace('bg-', 'text-')}`} />
                  </div>
                  <span className="font-medium">{item.label}</span>
                </div>
                <div className="text-right">
                  <p className="font-semibold">${item.value.toLocaleString()}</p>
                  <p className="text-xs text-slate-500">
                    {grandTotal > 0 ? ((item.value / grandTotal) * 100).toFixed(0) : 0}%
                  </p>
                </div>
              </div>
              <Progress 
                value={grandTotal > 0 ? (item.value / grandTotal) * 100 : 0} 
                className="h-2"
              />
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Pie Chart */}
      {pieData.length > 0 && (
        <Card className="lg:col-span-1">
          <CardHeader>
            <CardTitle className="text-lg">Spending Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={pieData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={80}
                    paddingAngle={5}
                    dataKey="value"
                  >
                    {pieData.map((entry, index) => (
                      <Cell key={index} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip 
                    formatter={(value) => `$${value.toLocaleString()}`}
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </div>
            <div className="flex flex-wrap gap-2 mt-4 justify-center">
              {pieData.map((item, i) => (
                <div key={i} className="flex items-center gap-1.5 text-xs">
                  <div className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }} />
                  <span className="text-slate-600">{item.name}</span>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}

      {/* Bar Chart by City */}
      {stopData.length > 0 && (
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle className="text-lg">Cost by City</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="h-64">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={stopData} layout="vertical">
                  <XAxis type="number" tickFormatter={(v) => `$${v}`} />
                  <YAxis type="category" dataKey="name" width={80} />
                  <Tooltip 
                    formatter={(value) => `$${value.toLocaleString()}`}
                    contentStyle={{ borderRadius: '8px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                  />
                  <Bar dataKey="accommodation" stackId="a" fill="#10b981" name="Accommodation" />
                  <Bar dataKey="transport" stackId="a" fill="#3b82f6" name="Transport" />
                  <Bar dataKey="activities" stackId="a" fill="#f59e0b" name="Activities" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </CardContent>
        </Card>
      )}

      {/* Empty State */}
      {grandTotal === 0 && (
        <Card className="lg:col-span-3 border-dashed border-2">
          <CardContent className="py-12 text-center">
            <DollarSign className="h-12 w-12 mx-auto text-slate-300 mb-4" />
            <h3 className="text-lg font-semibold text-slate-900 mb-2">No budget data yet</h3>
            <p className="text-slate-500">Add costs to your stops and activities to see the breakdown</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}