import React from 'react';
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { 
  Clock, DollarSign, MapPin, MoreVertical, 
  Edit, Trash2, CheckCircle, GripVertical
} from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { cn } from "@/lib/utils";

const categoryIcons = {
  sightseeing: "🏛️",
  food: "🍽️",
  adventure: "🎢",
  culture: "🎭",
  shopping: "🛍️",
  relaxation: "🧘",
  nightlife: "🌙",
  nature: "🌿",
  other: "✨"
};

const categoryColors = {
  sightseeing: "bg-blue-100 text-blue-700 border-blue-200",
  food: "bg-orange-100 text-orange-700 border-orange-200",
  adventure: "bg-red-100 text-red-700 border-red-200",
  culture: "bg-purple-100 text-purple-700 border-purple-200",
  shopping: "bg-pink-100 text-pink-700 border-pink-200",
  relaxation: "bg-teal-100 text-teal-700 border-teal-200",
  nightlife: "bg-indigo-100 text-indigo-700 border-indigo-200",
  nature: "bg-green-100 text-green-700 border-green-200",
  other: "bg-slate-100 text-slate-700 border-slate-200"
};

export default function ActivityCard({ 
  activity, 
  onEdit, 
  onDelete,
  onToggleBooked,
  isDragging = false,
  dragHandleProps = {},
  compact = false
}) {
  if (compact) {
    return (
      <div className={cn(
        "flex items-center gap-3 p-3 bg-white rounded-lg border border-slate-100 hover:border-slate-200 transition-colors",
        activity.is_booked && "bg-emerald-50/50 border-emerald-100"
      )}>
        <span className="text-lg">{categoryIcons[activity.category] || "✨"}</span>
        <div className="flex-1 min-w-0">
          <p className={cn(
            "text-sm font-medium text-slate-800 truncate",
            activity.is_booked && "text-emerald-700"
          )}>
            {activity.name}
          </p>
          <div className="flex items-center gap-2 text-xs text-slate-500">
            {activity.start_time && <span>{activity.start_time}</span>}
            {activity.duration_hours && (
              <>
                <span>•</span>
                <span>{activity.duration_hours}h</span>
              </>
            )}
          </div>
        </div>
        {activity.cost > 0 && (
          <Badge variant="outline" className="text-xs">
            ${activity.cost}
          </Badge>
        )}
      </div>
    );
  }

  return (
    <Card className={cn(
      "bg-white border-0 shadow-sm hover:shadow-md transition-all duration-200 rounded-xl",
      isDragging && "shadow-lg ring-2 ring-emerald-500",
      activity.is_booked && "ring-1 ring-emerald-200 bg-emerald-50/30"
    )}>
      <CardContent className="p-4">
        <div className="flex items-start gap-3">
          {/* Drag Handle */}
          <div 
            {...dragHandleProps}
            className="mt-0.5 cursor-grab active:cursor-grabbing p-1 rounded hover:bg-slate-100"
          >
            <GripVertical className="h-4 w-4 text-slate-400" />
          </div>

          {/* Category Icon */}
          <div className="flex-shrink-0 w-10 h-10 rounded-xl bg-slate-100 flex items-center justify-center text-xl">
            {categoryIcons[activity.category] || "✨"}
          </div>

          {/* Content */}
          <div className="flex-1 min-w-0">
            <div className="flex items-start justify-between gap-2">
              <div>
                <h4 className="font-medium text-slate-900">{activity.name}</h4>
                <div className="flex flex-wrap items-center gap-2 mt-1">
                  <Badge className={cn("text-xs border", categoryColors[activity.category])}>
                    {activity.category}
                  </Badge>
                  {activity.is_booked && (
                    <Badge className="text-xs bg-emerald-100 text-emerald-700 border-emerald-200">
                      <CheckCircle className="h-3 w-3 mr-1" />
                      Booked
                    </Badge>
                  )}
                </div>
              </div>

              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" size="icon" className="h-7 w-7">
                    <MoreVertical className="h-4 w-4" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onClick={() => onToggleBooked?.(activity)}>
                    <CheckCircle className="mr-2 h-4 w-4" />
                    {activity.is_booked ? 'Mark as Not Booked' : 'Mark as Booked'}
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onEdit?.(activity)}>
                    <Edit className="mr-2 h-4 w-4" />
                    Edit
                  </DropdownMenuItem>
                  <DropdownMenuItem onClick={() => onDelete?.(activity)} className="text-red-600">
                    <Trash2 className="mr-2 h-4 w-4" />
                    Remove
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </div>

            {/* Description */}
            {activity.description && (
              <p className="text-sm text-slate-500 mt-2 line-clamp-2">{activity.description}</p>
            )}

            {/* Meta Info */}
            <div className="flex flex-wrap items-center gap-3 mt-3 text-xs text-slate-500">
              {activity.start_time && (
                <div className="flex items-center gap-1">
                  <Clock className="h-3.5 w-3.5" />
                  <span>{activity.start_time}</span>
                </div>
              )}
              {activity.duration_hours && (
                <div className="flex items-center gap-1">
                  <Clock className="h-3.5 w-3.5" />
                  <span>{activity.duration_hours} hours</span>
                </div>
              )}
              {activity.cost > 0 && (
                <div className="flex items-center gap-1">
                  <DollarSign className="h-3.5 w-3.5" />
                  <span>${activity.cost}</span>
                </div>
              )}
              {activity.location && (
                <div className="flex items-center gap-1">
                  <MapPin className="h-3.5 w-3.5" />
                  <span className="truncate max-w-32">{activity.location}</span>
                </div>
              )}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}