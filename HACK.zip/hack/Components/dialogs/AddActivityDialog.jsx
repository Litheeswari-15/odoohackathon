import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient } from '@tanstack/react-query';
import { format } from 'date-fns';
import { Clock, DollarSign, MapPin, Loader2, Calendar } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { toast } from "sonner";

const categories = [
  { value: 'sightseeing', label: '🏛️ Sightseeing' },
  { value: 'food', label: '🍽️ Food & Dining' },
  { value: 'adventure', label: '🎢 Adventure' },
  { value: 'culture', label: '🎭 Culture' },
  { value: 'shopping', label: '🛍️ Shopping' },
  { value: 'relaxation', label: '🧘 Relaxation' },
  { value: 'nightlife', label: '🌙 Nightlife' },
  { value: 'nature', label: '🌿 Nature' },
  { value: 'other', label: '✨ Other' },
];

const timeSlots = [
  '06:00', '07:00', '08:00', '09:00', '10:00', '11:00',
  '12:00', '13:00', '14:00', '15:00', '16:00', '17:00',
  '18:00', '19:00', '20:00', '21:00', '22:00'
];

export default function AddActivityDialog({ open, onClose, tripId, stop, editingActivity }) {
  const queryClient = useQueryClient();

  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: 'sightseeing',
    date: '',
    start_time: '10:00',
    duration_hours: 2,
    cost: 0,
    location: '',
    is_booked: false
  });

  useEffect(() => {
    if (editingActivity) {
      setFormData({
        name: editingActivity.name || '',
        description: editingActivity.description || '',
        category: editingActivity.category || 'sightseeing',
        date: editingActivity.date || '',
        start_time: editingActivity.start_time || '10:00',
        duration_hours: editingActivity.duration_hours || 2,
        cost: editingActivity.cost || 0,
        location: editingActivity.location || '',
        is_booked: editingActivity.is_booked || false
      });
    } else if (stop) {
      setFormData(prev => ({
        ...prev,
        date: stop.arrival_date || '',
        name: '',
        description: '',
        category: 'sightseeing',
        start_time: '10:00',
        duration_hours: 2,
        cost: 0,
        location: '',
        is_booked: false
      }));
    }
  }, [editingActivity, stop, open]);

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.Activity.create({
      ...data,
      trip_id: tripId,
      stop_id: stop?.id
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['activities', tripId] });
      toast.success('Activity added!');
      onClose();
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data) => base44.entities.Activity.update(editingActivity.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['activities', tripId] });
      toast.success('Activity updated!');
      onClose();
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.date) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (editingActivity) {
      updateMutation.mutate(formData);
    } else {
      createMutation.mutate(formData);
    }
  };

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>
            {editingActivity ? 'Edit Activity' : 'Add Activity'}
            {stop && !editingActivity && (
              <span className="text-slate-500 font-normal ml-2">in {stop.city_name}</span>
            )}
          </DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          {/* Activity Name */}
          <div className="space-y-2">
            <Label>Activity Name *</Label>
            <Input
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="e.g., Visit Eiffel Tower"
            />
          </div>

          {/* Category */}
          <div className="space-y-2">
            <Label>Category</Label>
            <Select 
              value={formData.category} 
              onValueChange={(value) => setFormData({ ...formData, category: value })}
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {categories.map(cat => (
                  <SelectItem key={cat.value} value={cat.value}>
                    {cat.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Date */}
          <div className="space-y-2">
            <Label>Date *</Label>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" className="w-full justify-start">
                  <Calendar className="mr-2 h-4 w-4 text-slate-400" />
                  {formData.date 
                    ? format(new Date(formData.date), 'MMM d, yyyy')
                    : 'Select date'}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <CalendarComponent
                  mode="single"
                  selected={formData.date ? new Date(formData.date) : undefined}
                  onSelect={(date) => setFormData({ 
                    ...formData, 
                    date: date ? format(date, 'yyyy-MM-dd') : '' 
                  })}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          {/* Time & Duration */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Start Time</Label>
              <Select 
                value={formData.start_time} 
                onValueChange={(value) => setFormData({ ...formData, start_time: value })}
              >
                <SelectTrigger>
                  <Clock className="mr-2 h-4 w-4 text-slate-400" />
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {timeSlots.map(time => (
                    <SelectItem key={time} value={time}>{time}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Duration (hours)</Label>
              <Input
                type="number"
                min="0.5"
                step="0.5"
                value={formData.duration_hours}
                onChange={(e) => setFormData({ ...formData, duration_hours: parseFloat(e.target.value) || 0 })}
              />
            </div>
          </div>

          {/* Cost & Location */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Cost</Label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input
                  type="number"
                  min="0"
                  value={formData.cost}
                  onChange={(e) => setFormData({ ...formData, cost: parseFloat(e.target.value) || 0 })}
                  className="pl-9"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Location</Label>
              <div className="relative">
                <MapPin className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  placeholder="Address"
                  className="pl-9"
                />
              </div>
            </div>
          </div>

          {/* Description */}
          <div className="space-y-2">
            <Label>Description</Label>
            <Textarea
              value={formData.description}
              onChange={(e) => setFormData({ ...formData, description: e.target.value })}
              placeholder="Additional details..."
              rows={3}
            />
          </div>

          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={isPending}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {editingActivity ? 'Update' : 'Add Activity'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}