import React, { useState, useEffect } from 'react';
import { base44 } from '@/api/base44Client';
import { useMutation, useQueryClient, useQuery } from '@tanstack/react-query';
import { format } from 'date-fns';
import { MapPin, Calendar, DollarSign, Search, Loader2 } from 'lucide-react';
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Calendar as CalendarComponent } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { toast } from "sonner";

const popularCities = [
  { name: "Paris", country: "France" },
  { name: "Tokyo", country: "Japan" },
  { name: "New York", country: "USA" },
  { name: "London", country: "UK" },
  { name: "Barcelona", country: "Spain" },
  { name: "Rome", country: "Italy" },
  { name: "Bangkok", country: "Thailand" },
  { name: "Dubai", country: "UAE" },
  { name: "Sydney", country: "Australia" },
  { name: "Amsterdam", country: "Netherlands" },
];

export default function AddStopDialog({ open, onClose, tripId, tripDates, editingStop }) {
  const queryClient = useQueryClient();
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  const [formData, setFormData] = useState({
    city_name: '',
    country: '',
    arrival_date: '',
    departure_date: '',
    accommodation_cost: 0,
    transport_cost: 0,
    notes: ''
  });

  useEffect(() => {
    if (editingStop) {
      setFormData({
        city_name: editingStop.city_name || '',
        country: editingStop.country || '',
        arrival_date: editingStop.arrival_date || '',
        departure_date: editingStop.departure_date || '',
        accommodation_cost: editingStop.accommodation_cost || 0,
        transport_cost: editingStop.transport_cost || 0,
        notes: editingStop.notes || ''
      });
    } else {
      setFormData({
        city_name: '',
        country: '',
        arrival_date: tripDates?.start || '',
        departure_date: tripDates?.end || '',
        accommodation_cost: 0,
        transport_cost: 0,
        notes: ''
      });
    }
  }, [editingStop, tripDates, open]);

  const { data: existingStops = [] } = useQuery({
    queryKey: ['stops', tripId],
    queryFn: () => base44.entities.TripStop.filter({ trip_id: tripId }),
    enabled: !!tripId,
  });

  const createMutation = useMutation({
    mutationFn: (data) => base44.entities.TripStop.create({
      ...data,
      trip_id: tripId,
      order: existingStops.length
    }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['stops', tripId] });
      toast.success('Stop added successfully!');
      onClose();
    },
  });

  const updateMutation = useMutation({
    mutationFn: (data) => base44.entities.TripStop.update(editingStop.id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['stops', tripId] });
      toast.success('Stop updated successfully!');
      onClose();
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!formData.city_name || !formData.arrival_date || !formData.departure_date) {
      toast.error('Please fill in all required fields');
      return;
    }

    if (editingStop) {
      updateMutation.mutate(formData);
    } else {
      createMutation.mutate(formData);
    }
  };

  const selectCity = (city) => {
    setFormData({ ...formData, city_name: city.name, country: city.country });
    setSearchOpen(false);
  };

  const filteredCities = popularCities.filter(city =>
    city.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
    city.country.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const isPending = createMutation.isPending || updateMutation.isPending;

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{editingStop ? 'Edit Stop' : 'Add New Stop'}</DialogTitle>
        </DialogHeader>

        <form onSubmit={handleSubmit} className="space-y-4 py-4">
          {/* City Selection */}
          <div className="space-y-2">
            <Label>City *</Label>
            <Popover open={searchOpen} onOpenChange={setSearchOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  className="w-full justify-start"
                >
                  {formData.city_name ? (
                    <div className="flex items-center gap-2">
                      <MapPin className="h-4 w-4 text-emerald-500" />
                      <span>{formData.city_name}</span>
                      {formData.country && (
                        <span className="text-slate-400">• {formData.country}</span>
                      )}
                    </div>
                  ) : (
                    <div className="flex items-center gap-2 text-slate-400">
                      <Search className="h-4 w-4" />
                      Search for a city...
                    </div>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-full p-0" align="start">
                <Command>
                  <CommandInput 
                    placeholder="Search cities..." 
                    value={searchQuery}
                    onValueChange={setSearchQuery}
                  />
                  <CommandList>
                    <CommandEmpty>
                      <div className="p-2">
                        <Button
                          type="button"
                          variant="ghost"
                          className="w-full justify-start"
                          onClick={() => {
                            setFormData({ ...formData, city_name: searchQuery, country: '' });
                            setSearchOpen(false);
                          }}
                        >
                          <MapPin className="h-4 w-4 mr-2" />
                          Add "{searchQuery}"
                        </Button>
                      </div>
                    </CommandEmpty>
                    <CommandGroup heading="Popular Cities">
                      {filteredCities.map((city) => (
                        <CommandItem
                          key={`${city.name}-${city.country}`}
                          onSelect={() => selectCity(city)}
                        >
                          <MapPin className="h-4 w-4 mr-2 text-slate-400" />
                          {city.name}
                          <span className="ml-auto text-slate-400">{city.country}</span>
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
          </div>

          {/* Country */}
          <div className="space-y-2">
            <Label>Country</Label>
            <Input
              value={formData.country}
              onChange={(e) => setFormData({ ...formData, country: e.target.value })}
              placeholder="Enter country"
            />
          </div>

          {/* Dates */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Arrival *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start">
                    <Calendar className="mr-2 h-4 w-4 text-slate-400" />
                    {formData.arrival_date 
                      ? format(new Date(formData.arrival_date), 'MMM d, yyyy')
                      : 'Select'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <CalendarComponent
                    mode="single"
                    selected={formData.arrival_date ? new Date(formData.arrival_date) : undefined}
                    onSelect={(date) => setFormData({ 
                      ...formData, 
                      arrival_date: date ? format(date, 'yyyy-MM-dd') : '' 
                    })}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>

            <div className="space-y-2">
              <Label>Departure *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button variant="outline" className="w-full justify-start">
                    <Calendar className="mr-2 h-4 w-4 text-slate-400" />
                    {formData.departure_date 
                      ? format(new Date(formData.departure_date), 'MMM d, yyyy')
                      : 'Select'}
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-auto p-0">
                  <CalendarComponent
                    mode="single"
                    selected={formData.departure_date ? new Date(formData.departure_date) : undefined}
                    onSelect={(date) => setFormData({ 
                      ...formData, 
                      departure_date: date ? format(date, 'yyyy-MM-dd') : '' 
                    })}
                    initialFocus
                  />
                </PopoverContent>
              </Popover>
            </div>
          </div>

          {/* Costs */}
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>Accommodation Cost</Label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input
                  type="number"
                  min="0"
                  value={formData.accommodation_cost}
                  onChange={(e) => setFormData({ ...formData, accommodation_cost: parseFloat(e.target.value) || 0 })}
                  className="pl-9"
                />
              </div>
            </div>

            <div className="space-y-2">
              <Label>Transport Cost</Label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-slate-400" />
                <Input
                  type="number"
                  min="0"
                  value={formData.transport_cost}
                  onChange={(e) => setFormData({ ...formData, transport_cost: parseFloat(e.target.value) || 0 })}
                  className="pl-9"
                />
              </div>
            </div>
          </div>

          {/* Notes */}
          <div className="space-y-2">
            <Label>Notes</Label>
            <Textarea
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              placeholder="Any notes for this stop..."
              rows={3}
            />
          </div>

          <DialogFooter className="pt-4">
            <Button type="button" variant="outline" onClick={onClose}>
              Cancel
            </Button>
            <Button 
              type="submit" 
              disabled={isPending}
              className="bg-emerald-600 hover:bg-emerald-700"
            >
              {isPending && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {editingStop ? 'Update Stop' : 'Add Stop'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}