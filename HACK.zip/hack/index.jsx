import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import Input from '../components/ui/Input';
import Button from '../components/ui/Button';
import { Map, ArrowRight } from 'lucide-react';
const Login = () => {
    const navigate = useNavigate();
    const [loading, setLoading] = useState(false);
    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        // Simulate login for now
        setTimeout(() => {
            setLoading(false);
            // alert('Login implementation pending backend integration');
            navigate('/');
        }, 1500);
    };
    return (
        <div className="flex-center" style={{ minHeight: '100vh', padding: '1rem', position: 'relative', overflow: 'hidden' }}>
            {/* Background Blob */}
            <div style={{
                position: 'absolute',
                top: '50%',
                left: '50%',
                transform: 'translate(-50%, -50%)',
                width: '600px',
                height: '600px',
                background: 'radial-gradient(circle, rgba(99, 102, 241, 0.2) 0%, rgba(99, 102, 241, 0) 70%)',
                zIndex: -1,
                pointerEvents: 'none'
            }} />
            <div className="glass-panel" style={{ width: '100%', maxWidth: '400px', padding: '2.5rem' }}>
                <div style={{ textAlign: 'center', marginBottom: '2rem' }}>
                    <div className="flex-center" style={{ marginBottom: '1rem' }}>
                         {/* Switched to simple text title to match user request style more closely, or keep icon? keeping icon for brand consistency */}
                        <Map size={48} className="text-gradient" color="var(--color-primary)" />
                    </div>
                    <h1 style={{ fontSize: '2rem', marginBottom: '0.5rem' }}>Welcome Back</h1>
                    <p style={{ color: 'var(--color-text-muted)' }}>Enter your details to access your journeys</p>
                </div>
                <form onSubmit={handleSubmit}>
                    <Input label="Email Address" type="email" placeholder="Email Address" required />
                    <Input label="Password" type="password" placeholder="Password" required />
                    <div style={{ display: 'flex', justifyContent: 'flex-end', marginBottom: '1.5rem', fontSize: '0.875rem' }}>
                        <Link to="/forgot-password" style={{ color: 'var(--color-primary)' }}>Forgot Password?</Link>
                    </div>
                    <Button type="submit" variant="primary" style={{ width: '100%' }} size="lg" disabled={loading}>
                        {loading ? 'Signing in...' : 'Sign In'} 
                        {!loading && <ArrowRight size={18} />}
                    </Button>
                </form>
                <div style={{ 
                    display: 'flex', 
                    alignItems: 'center', 
                    gap: '1rem', 
                    margin: '2rem 0', 
                    color: 'var(--color-text-muted)',
                    fontSize: '0.75rem',
                    fontWeight: '600'
                }}>
                    <div style={{ height: '1px', flex: 1, background: 'var(--glass-border)' }}></div>
                    <span>OR CONTINUE WITH</span>
                    <div style={{ height: '1px', flex: 1, background: 'var(--glass-border)' }}></div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: '1rem', marginBottom: '2rem' }}>
                    <Button variant="secondary" type="button">Google</Button>
                    <Button variant="secondary" type="button">Apple</Button>
                </div>
                <div style={{ textAlign: 'center', fontSize: '0.875rem', color: 'var(--color-text-muted)' }}>
                    Don't have an account? <Link to="/signup" style={{ color: 'var(--color-primary)', fontWeight: '600' }}>Sign Up</Link>
                </div>
            </div>
        </div>
    );
};
export default Login;